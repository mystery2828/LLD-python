class Guest(object):
    def __init__(self, id, name):
        self.id = id
        self.name = name
    
    def getId(self):
        return self.id
    
    def getName(self):
        return self.name