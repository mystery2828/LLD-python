class Reservation(object):
    def __init__(self, guest, room):
        self.guest = guest
        self.room = room