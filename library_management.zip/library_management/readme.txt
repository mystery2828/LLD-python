Classes: Book, User, Library
Features: Add/Remove Books, Borrow/Return Books, User Management.